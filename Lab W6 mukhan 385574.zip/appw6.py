import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.feature_selection import mutual_info_classif
from deap import base, creator, tools, algorithms
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder

# Set up the Streamlit app
st.title("Genetic Algorithm Feature Selection (GA-FSS)")
st.write("Upload a CSV file to perform feature selection using a Genetic Algorithm.")

# File uploader
uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file is not None:
    # Load the data
    data = pd.read_csv(uploaded_file)
    def preprocess_data(data):
        # Handle missing values
        imputer = SimpleImputer(strategy='mean')
        data_imputed = pd.DataFrame(imputer.fit_transform(data.select_dtypes(include=[float, int])), columns=data.select_dtypes(include=[float, int]).columns)
        
        # Encode categorical variables
        categorical_columns = data.select_dtypes(include=[object]).columns
        le = LabelEncoder()
        for col in categorical_columns:
            data_imputed[col] = le.fit_transform(data[col])
        
        return data_imputed
    data = preprocess_data(data)
    st.write("Data Preview:")
    st.write(data.head())

    # Select target variable
    target_column = st.selectbox("Select the target variable", data.columns)

    # Prepare the data
    X = data.drop(columns=[target_column])
    y = data[target_column]

    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Baseline accuracy
    dt = DecisionTreeClassifier(random_state=42)
    dt.fit(X_train, y_train)
    y_pred = dt.predict(X_test)
    baseline_accuracy = accuracy_score(y_test, y_pred)
    st.write(f"Baseline Accuracy: {baseline_accuracy:.4f}")

    # Define the evaluation function for GA
    def evaluate(individual):
        selected_features = [index for index in range(len(individual)) if individual[index] == 1]
        if len(selected_features) == 0:
            return 0,
        
        X_train_selected = X_train.iloc[:, selected_features]
        X_test_selected = X_test.iloc[:, selected_features]
        
        dt = DecisionTreeClassifier(random_state=42)
        dt.fit(X_train_selected, y_train)
        
        y_pred = dt.predict(X_test_selected)
        accuracy = accuracy_score(y_test, y_pred)
        
        mutual_info = mutual_info_classif(X_train, y_train)
        relevancy = np.sum(mutual_info[selected_features]) / len(selected_features)
        
        fitness = accuracy + relevancy
        return fitness,

    # Set up the Genetic Algorithm
    creator.create("FitnessMax", base.Fitness, weights=(1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMax)

    toolbox = base.Toolbox()
    toolbox.register("attr_bool", np.random.randint, 2)
    toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.attr_bool, n=len(X_train.columns))
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)

    toolbox.register("mate", tools.cxTwoPoint)
    toolbox.register("mutate", tools.mutFlipBit, indpb=0.05)
    toolbox.register("select", tools.selTournament, tournsize=3)
    toolbox.register("evaluate", evaluate)

    # Run the Genetic Algorithm
    if st.button("Run Genetic Algorithm"):
        with st.spinner("Running Genetic Algorithm..."):
            population = toolbox.population(n=50)
            NGEN, CXPB, MUTPB = 20, 0.5, 0.2

            for gen in range(NGEN):
                offspring = algorithms.varAnd(population, toolbox, cxpb=CXPB, mutpb=MUTPB)
                fits = list(map(toolbox.evaluate, offspring))
                
                for fit, ind in zip(fits, offspring):
                    ind.fitness.values = fit
                
                population = toolbox.select(offspring, k=len(population))

            best_individual = tools.selBest(population, k=1)[0]
            selected_features = [index for index in range(len(best_individual)) if best_individual[index] == 1]
            
            st.write("Selected Features:", [X.columns[i] for i in selected_features])
            
            # Train on selected features
            X_train_selected = X_train.iloc[:, selected_features]
            X_test_selected = X_test.iloc[:, selected_features]

            dt.fit(X_train_selected, y_train)
            y_pred = dt.predict(X_test_selected)
            selected_accuracy = accuracy_score(y_test, y_pred)
            st.write(f"Accuracy with Selected Features: {selected_accuracy:.4f}")
            
            # Compare accuracies
            st.write("Comparison:")
            st.write(f"Baseline Accuracy: {baseline_accuracy:.4f}")
            st.write(f"Accuracy with Selected Features: {selected_accuracy:.4f}")
            st.write(f"Number of original features: {X.shape[1]}")
            st.write(f"Number of selected features: {len(selected_features)}")

            if selected_accuracy > baseline_accuracy:
                st.success("Feature selection improved the model's accuracy!")
            elif selected_accuracy == baseline_accuracy:
                st.info("Feature selection maintained the model's accuracy while reducing the number of features.")
            else:
                st.warning("Feature selection did not improve the model's accuracy. Consider adjusting the GA parameters or using a different feature selection method.")